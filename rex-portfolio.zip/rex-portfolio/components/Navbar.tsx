export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-[var(--bg)]/80 backdrop-blur border-b border-black/5">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <a href="#home" className="font-display text-2xl text-primaryDark">Rex Danyo</a>
        <div className="flex gap-4 text-sm">
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#experience">Experience</a>
          <a href="#testimonials">Testimonials</a>
          <a href="#contact">Contact</a>
        </div>
      </div>
    </nav>
  );
}