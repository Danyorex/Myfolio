export default function Testimonials() {
  return (
    <section id="testimonials" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">Testimonials</h2>
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="p-4 border rounded">"Rex delivered a fast, beautiful site that converts." — Client</div>
        <div className="p-4 border rounded">"Great communication, great results." — Partner</div>
        <div className="p-4 border rounded">"Understood our brand and nailed the details." — Stakeholder</div>
      </div>
    </section>
  );
}