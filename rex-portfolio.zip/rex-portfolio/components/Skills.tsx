export default function Skills() {
  return (
    <section id="skills" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">Skills</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        <div className="p-4 border rounded">WordPress</div>
        <div className="p-4 border rounded">Webflow</div>
        <div className="p-4 border rounded">Elementor</div>
        <div className="p-4 border rounded">React</div>
        <div className="p-4 border rounded">No-Code</div>
        <div className="p-4 border rounded">Branding</div>
      </div>
    </section>
  );
}