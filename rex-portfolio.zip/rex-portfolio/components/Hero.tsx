export default function Hero() {
  return (
    <section id="home" className="py-20 text-center">
      <h1 className="font-display text-4xl md:text-6xl">Hi, I’m <span className="text-accent">Rex</span> — I build digital experiences</h1>
      <p className="mt-4 max-w-2xl mx-auto text-neutral-700">WordPress & No-Code Specialist with an IT and creative design background.</p>
      <div className="mt-8 flex justify-center gap-4">
        <a href="#projects" className="px-5 py-3 bg-primaryDark text-lightBg rounded-md">View My Work</a>
        <a href="/cv.pdf" download className="px-5 py-3 border border-primaryDark rounded-md">Download CV</a>
      </div>
    </section>
  );
}