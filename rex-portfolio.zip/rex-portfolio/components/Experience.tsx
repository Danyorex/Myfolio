export default function Experience() {
  return (
    <section id="experience" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">Experience & Education</h2>
      <ul className="space-y-3">
        <li>2025 — Freelance WP & No-Code Specialist</li>
        <li>2023–2024 — Web Designer/Developer</li>
        <li>2019–2023 — IT & Creative Design</li>
      </ul>
    </section>
  );
}