export default function Projects() {
  return (
    <section id="projects" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">Projects</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="p-4 border rounded">Project 1</div>
        <div className="p-4 border rounded">Project 2</div>
        <div className="p-4 border rounded">Project 3</div>
      </div>
    </section>
  );
}