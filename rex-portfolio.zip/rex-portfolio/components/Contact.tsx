export default function Contact() {
  return (
    <section id="contact" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">Contact Me</h2>
      <form className="space-y-4 max-w-md">
        <input type="text" placeholder="Your name" className="w-full px-4 py-2 border rounded" />
        <input type="email" placeholder="Email address" className="w-full px-4 py-2 border rounded" />
        <textarea placeholder="Your message" className="w-full px-4 py-2 border rounded" rows={4}></textarea>
        <button type="submit" className="px-5 py-2 bg-accent text-white rounded">Send</button>
      </form>
    </section>
  );
}