export default function Footer() {
  return (
    <footer className="py-8 border-t text-center text-sm">
      © {new Date().getFullYear()} Rex Danyo. All rights reserved.
    </footer>
  );
}