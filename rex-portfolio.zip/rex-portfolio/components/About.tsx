export default function About() {
  return (
    <section id="about" className="py-16 max-w-6xl mx-auto px-4">
      <h2 className="font-display text-3xl mb-6">About Me</h2>
      <p>I’m <strong>Joshua Danyo Rex (Rex Danyo)</strong>, a WordPress & No-Code specialist focused on building branded, high-performing websites.</p>
    </section>
  );
}